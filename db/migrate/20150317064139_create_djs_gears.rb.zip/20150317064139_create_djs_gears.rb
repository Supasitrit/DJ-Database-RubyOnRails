class CreateDjsGears < ActiveRecord::Migration
  def change
    create_table :djs_gears do |t|

      t.timestamps null: false
    end
  end
end
